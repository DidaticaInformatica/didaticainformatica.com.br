# Didática Informática — V4 Identidade Visual

Versão focada em UI/UX mais profissional e 100% alinhada à identidade visual da Didática.

## Direção visual

- Azul escuro como base institucional.
- Azul médio para confiança e tecnologia.
- Ciano como cor de destaque da marca.
- Fundo branco e cinza claro para leitura.
- Menos emojis no site.
- Mais hierarquia, espaçamento e consistência.
- Visual menos genérico e mais proprietário.
- Uso da logo em pontos estratégicos.

## Arquivos

```txt
index.html
styles.css
script.js
README.md
assets/logo-didatica.png
```

## Informações inseridas

- Didática Informática — Escola de Tecnologia
- Capim Grosso-BA
- Avenida ACM, Centro, em cima do Banco do Brasil
- WhatsApp: (74) 99136-8794
- Instagram: @didaticainf
- Alunos a partir de 11 anos
- Certificado válido em todo o Brasil

## Como atualizar no GitHub

Substitua os arquivos atuais do repositório por estes arquivos e faça commit.

O `index.html` precisa ficar na raiz do repositório.
